import speechToText
import audio

string = speechToText.speechToText("audioFile.wav")